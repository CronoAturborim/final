from setuptools import setup, find_packages

setup(
    name="lols0",
    version="0.2",
    license="MIT",
    description="base de datos",
    author="Andres Pérez C",
    packages=find_packages(),
    url="https://github.com/CronoAturborim/final"

)
