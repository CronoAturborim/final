from cosa.prog import agregar 
from cosa.prog import actu 
from cosa.prog import borrar
from cosa.prog import principal
from cosa.prog import ver_datos


